const Membership_Registration_data = [
    {
        title:"ASSOCIATE MEMBER",
        image:"/images/plan.png",
        price:"600",
        Billed_Yearly:"Billed Yearly",
        subscribe:"SUBSCRIBE",
        des1:"Anyone interested in Transactional Analysis",
        des2:"No Voting Rights",
    },
    {
        title:"ASSOCIATE MEMBER",
        image:"/images/plan.png",
        price:"800",
        Billed_Yearly:"Billed Yearly",
        subscribe:"SUBSCRIBE",
        des1:"Anyone interested in Transactional Analysis",
        des2:"Voting Rights",
    },
    {
        title:"ASSOCIATE MEMBER",
        image:"/images/plan.png",
        price:"1500",
        Billed_Yearly:"Billed Yearly",
        subscribe:"SUBSCRIBE",
        des1:"Must have Passed CTA",
        des2:"Voting Rights",
    },
    {
        title:"ASSOCIATE MEMBER",
        image:"/images/plan.png",
        price:"15000",
        Billed_Yearly:"Billed Yearly",
        subscribe:"SUBSCRIBE",
        des1:"Must have Passed CTA",
        des2:"Valid for 15 years",
    },
]

export default Membership_Registration_data;