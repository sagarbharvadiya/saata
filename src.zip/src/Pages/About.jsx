import React from 'react'
// import AboutUs from '../Components/AboutUs'
// import AboutTA from '../Components/AboutTA'
import HistoryOrigin from '../Components/HistoryOrigin'

const About = () => {
    return (
        <>
            {/* <AboutUs /> */}
            {/* <AboutTA/> */}
            <HistoryOrigin/>
        </>
    )
}

export default About